sudo systemctl stop node-exporter.service
sudo systemctl disable node-exporter.service
sudo rm -rf /opt/node_exporter
rm -rf node*
