sudo cp node_exporter /opt
sudo cp node-exporter.service /usr/lib/systemd/system
sudo systemctl enable node-exporter.service
sudo systemctl start node-exporter.service

